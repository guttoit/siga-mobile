/** Automatically generated file. DO NOT MODIFY */
package org.sigmobile2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}