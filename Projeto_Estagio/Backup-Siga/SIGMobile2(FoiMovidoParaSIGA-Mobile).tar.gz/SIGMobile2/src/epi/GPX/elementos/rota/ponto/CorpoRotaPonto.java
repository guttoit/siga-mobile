package epi.GPX.elementos.rota.ponto;

import epi.GPX.elementos.ponto.CorpoPonto;

public class CorpoRotaPonto extends CorpoPonto{

	public CorpoRotaPonto(){
		super();
	}
	
	public String getConteudo(){
		
		return super.getConteudo();
	}
	
	public void setCampoNome(String nome){
		
		super.setCampoNome(nome);
	}
}
