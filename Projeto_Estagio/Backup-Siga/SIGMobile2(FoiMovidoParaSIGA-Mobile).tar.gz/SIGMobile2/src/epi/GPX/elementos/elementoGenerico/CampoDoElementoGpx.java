package epi.GPX.elementos.elementoGenerico;

public interface CampoDoElementoGpx {

	public void setValor(Object valor);
	
	public String getXmlDoCampo();
	
}
