package epi.GPX.elementos.elementoGenerico;

public interface ElementoGenericoObrigatorio {
	
	public String getConteudo();
	
	public int getPosicaoAddProxElemento();
	
	public int getTipoElemento();
}
