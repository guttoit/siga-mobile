import floppyforms as forms
from map.models import Geometry

class GMapGeometryWidget(forms.gis.GeometryWidget, forms.gis.BaseGMapWidget):
  pass

class GeometryForm(forms.ModelForm):
  geometry = forms.gis.GeometryField(widget=GMapGeometryWidget(attrs={
    'map_width': 800,
    'map_heigth': 800,
  }))

  class Meta:
    model = Geometry
