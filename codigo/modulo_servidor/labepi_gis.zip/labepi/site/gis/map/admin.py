from django.contrib.gis import admin
import floppyforms as forms
from map.models import *
from map.forms import *

class GeometryAdmin(admin.ModelAdmin):
  form = GeometryForm

admin.site.register(Type, admin.OSMGeoAdmin)
admin.site.register(Geometry, GeometryAdmin)
admin.site.register(Information, admin.OSMGeoAdmin)
admin.site.register(Presentation, admin.OSMGeoAdmin)
