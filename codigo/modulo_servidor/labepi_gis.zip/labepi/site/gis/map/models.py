from django.contrib.gis.db import models
from django.conf import settings
import json
import floppyforms as forms

class Presentation(models.Model):
  name = models.CharField(max_length=255)
  style = models.TextField()

  def natural_key(self):
    style_json = json.loads(self.style)
    if(style_json.has_key('externalGraphic')):
      style_json['externalGraphic'] = settings.MEDIA_URL + style_json['externalGraphic']
    if(style_json.has_key('backgroundGraphic')):
      style_json['backgroundGraphic'] = settings.MEDIA_URL + style_json['backgroundGraphic']

    return style_json

  def __unicode__(self):
    return self.name

class Type(models.Model):
  name = models.CharField(max_length=255)

  def __unicode__(self):
    return self.name

class Information(models.Model):
  title = models.CharField(max_length=255)
  content = models.TextField()

  def natural_key(self):
    return { u"title": self.title, u"content": self.content }

  def __unicode__(self):
    return self.title

class Geometry(models.Model):
  type = models.ForeignKey(Type)
  presentation = models.ForeignKey(Presentation)
  information = models.ForeignKey(Information)
  geometry = models.GeometryField(srid=900913)
  objects = models.GeoManager()

  def __unicode__(self):
    return self.type.name

