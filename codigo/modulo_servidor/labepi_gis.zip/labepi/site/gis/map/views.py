# -*- encoding: utf8 -*-
# Create your views here.
import json
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core import serializers
from django.contrib.gis.geos import Polygon
from map.models import *

def info(request, info_id):
  information = Information.objects.filter(id=info_id)

  response = serializers.serialize("json", information)

  return HttpResponse(response)

def layers(request):
  response = serializers.serialize("json", Type.objects.all(),
                                   use_natural_keys=True)

  return HttpResponse(response)

def geo(request, type_id):
  bbox = request.GET['bbox']
  left, bottom, right, top = bbox.split(',')

  poly = Polygon.from_bbox((left, bottom, right, top))
  #zoom = request.GET['zoom']

  geoms = Geometry.objects.filter(type__id=type_id)

  response = serializers.serialize("json", geoms, use_natural_keys=True,
      fields=('geometry', 'presentation', 'information'))

  return HttpResponse(response)

def index(request):
  return render_to_response('layout.html', {'debug' : settings.DEBUG},
                            context_instance=RequestContext(request))
