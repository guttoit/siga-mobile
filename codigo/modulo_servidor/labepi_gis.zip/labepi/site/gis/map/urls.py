from django.conf.urls.defaults import patterns, url

urlpatterns = patterns('map.views',
  url(r'^$', 'index'),
  url(r'^geo/$', 'layers'),
  url(r'^geo/info/(?P<info_id>\d+)/$', 'info'),
  url(r'^geo/(?P<type_id>\d+)/$', 'geo'),
)
