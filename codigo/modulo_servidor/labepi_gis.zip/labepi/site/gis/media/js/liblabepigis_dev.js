/*
 * Make variables available for easy debugging
 */
var map;
var map_center = [ -37.09, -6.466 ]; /**< geographic location of Caicó city */
var options = {
  div: "map",
  projection: new OpenLayers.Projection("EPSG:900913"),
  units: "m",
  maxResolution: 156543.0339,
  maxExtent: new OpenLayers.Bounds(
    -20037508, -20037508, 20037508, 20037508.34
)}; /**< map configuration options */
layers = []; /**< Holds all layers added by users */

/**
 * Class responsible for reading geographical information, which are obtained
 * in json format, and rendering them in stylized vector.
 */
var LabepiFormat = OpenLayers.Class(
    OpenLayers.Format.JSON,
    {
      read: function(data)
      {
        if(data)
        {
          if(typeof data == "string")
          {
            data = OpenLayers.Format.JSON.prototype.read.apply(this, [data]);
          }

          var features = [];
          var wkt = new OpenLayers.Format.WKT();
          for(var i = 0; i < data.length; i++)
          {
            var fields = data[i]['fields'];
            var feature = wkt.read(fields['geometry']);
            feature.style = fields['presentation'];
            feature.attributes.info = fields['information'];
            features.push(feature);
          }

          return features;
        }
      }
    }
);

/**
 * Creates vector layers from a json and store in layers global variable.
 *
 * The strategy used to retrieve information is BBOX, that is, information
 * will only be displayed if the user is viewing.
 */
function load_layers()
{
  var request = OpenLayers.Request.GET(
    {
      url: "geo", async: false
    }
  );

  if(request.responseText)
  {
    var json_format = new OpenLayers.Format.JSON();
    var json = json_format.read(request.responseText);

    for(var i = 0; i < json.length; i++)
    {
      var fields = json[i]['fields'];
      var name = fields['name'];
      var type_id = json[i]['pk'];

      var new_layer = new OpenLayers.Layer.Vector(
        name,
        {
          strategies:
          [
            new OpenLayers.Strategy.BBOX()
          ],
          protocol: new OpenLayers.Protocol.HTTP (
          {
            url: "geo/" + type_id + "/",
            format: new LabepiFormat()
          })
        }
      );

      layers.push(new_layer);
    }
  }
}

/**
 * Function to convert normal latitude/longitude to mercator easting/northings
 */
function coordinate_to_mercator(c)
{
  var lon = c.lon * 20037508.34 / 180;
  var lat = Math.log(Math.tan((90 + c.lat) * Math.PI / 360)) / (Math.PI / 180);

  lat = lat * 20037508.34 / 180;

  return new OpenLayers.LonLat(lon, lat);
}

/**
 * Returns the URL of the tile area where the user is viewing.
 *
 * @param bounds viewing area of the user.
 * @return URL of the tile.
 */
function osm_get_tile_url(bounds)
{
  var res = this.map.getResolution();
  var x = Math.round((bounds.left - this.maxExtent.left) / (res * this.tileSize.w));
  var y = Math.round((this.maxExtent.top - bounds.top) / (res * this.tileSize.h));
  var z = this.map.getZoom();
  var limit = Math.pow(2, z);
  if (y < 0 || y >= limit)
  {
    return OpenLayers.Util.getImagesLocation() + "404.png";
  }
  else
  {
    x = ((x % limit) + limit) % limit;
    return this.url + z + "/" + x + "/" + y + "." + this.type;
  }
}

/**
 * Initializing function
 */
function initialize()
{
  map = new OpenLayers.Map(options);
  load_layers();

  var google_aerial = new OpenLayers.Layer.Google (
    "Google Aerial (Base)",
    {type: google.maps.MapTypeId.SATELLITE, numZoomLevels: 22}
  );

  map.addControl(new OpenLayers.Control.LayerSwitcher());
  map.addControl(new OpenLayers.Control.Permalink());
  map.addControl(new OpenLayers.Control.MousePosition());

  map.addLayer(google_aerial);
  map.addLayer(
    new OpenLayers.Layer.TMS(
     "OpenStreetMap Mapnik",
     "http://localhost/tilecache/tilecache.cgi/1.0.0/osm/",
     {
       type: 'png',
       getURL: osm_get_tile_url,
       displayOutsideMaxExtent: false,
       isBaseLayer: false,
       visibility: true,
       numZoomLevels:19
     },
     {'buffer':1})
  );
  map.addLayers(layers);

  var select_control = new OpenLayers.Control.SelectFeature(layers);
  map.addControl(select_control);
  select_control.activate();

  function on_popup_close(evt)
  {
    // 'this' is the popup.
    var feature = this.feature;
    if (feature.layer)
    { // The feature is not destroyed
      select_control.unselect(feature);
    }
    else
    { // After "moveend" or "refresh" events on POIs layer all
             // features have been destroyed by the Strategy.BBOX
      this.destroy();
    }
  }

  function on_feature_select(evt)
  {
    feature = evt.feature;
    popup = new OpenLayers.Popup.FramedCloud(
        "featurePopup",
        feature.geometry.getBounds().getCenterLonLat(),
        new OpenLayers.Size(100,100),
        feature.attributes.info.title + "<hr>" +
        feature.attributes.info.content,
        null, true, on_popup_close
    );
    feature.popup = popup;
    popup.feature = feature;
    map.addPopup(popup, true);
  }

  function on_feature_unselect(evt) {
    feature = evt.feature;
    if (feature.popup) {
      popup.feature = null;
      map.removePopup(feature.popup);
      feature.popup.destroy();
      feature.popup = null;
    }
  }

  for(var i = 0; i < layers.length; i++)
  {
    layers[i].events.on({
        'featureselected': on_feature_select,
        'featureunselected': on_feature_unselect
    });
  }

  map.setCenter(
    new OpenLayers.LonLat(map_center[0], map_center[1]).transform(
      new OpenLayers.Projection("EPSG:4326"),
      map.getProjectionObject()
    ),
    13
  );
}
